export const Footer = () => {
  return (
    <footer className="app-footer">
      <p>© 2023 MyBlog. All rights reserved.</p>
    </footer>
  );
};
